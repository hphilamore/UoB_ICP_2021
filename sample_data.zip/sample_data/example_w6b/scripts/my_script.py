import sys
sys.path.append('../') # appends the python path with the directory one level up
sys.path.append('../fruit') # appends the python path with the directory one level up
import functions
import strawberry
