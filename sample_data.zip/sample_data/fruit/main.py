# main.py
import banana
# import strawberry
# print(banana.word)
# print(strawberry.word)

# import strawberry as s
# print(s.word)


from strawberry import *
print(word)