# banana.py
word = 'banana'

