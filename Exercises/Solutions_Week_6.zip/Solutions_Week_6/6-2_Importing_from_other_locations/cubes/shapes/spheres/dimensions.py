# Exercise 2.5

radius = 10 # m



