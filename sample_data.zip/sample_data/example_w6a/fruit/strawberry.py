# strawberry.py
word = 'strawberry'

